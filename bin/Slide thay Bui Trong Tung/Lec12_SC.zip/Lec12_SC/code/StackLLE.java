package samsung.java.stack;

import java.util.EmptyStackException;
import java.util.NoSuchElementException;

import samsung.java.linked.list.BasicLinkedList;

/**
 * An implementation of the IStack interface by inheriting the BasicLinkedList class.
 * @param <E> The type � the elements in this stack
 */
public class StackLLE<E> extends BasicLinkedList <E> implements IStack <E>  {

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#empty()
	 */
	public boolean empty() {
		return isEmpty();
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#peek()
	 */
	public E peek() throws EmptyStackException {
		try {
			return getFirst();
		} catch (NoSuchElementException e) {
			throw new EmptyStackException();
		}
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#pop()
	 */
	public E pop() throws EmptyStackException {
		E obj = peek();
		removeFirst();
		return obj;
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#push(java.lang.Object)
	 */
	public void push(E o) {
		addFirst(o);
	}

}
