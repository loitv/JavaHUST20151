package samsung.java.linked.list;

/**
 * The ListNode class demonstrates a node in the linked list.
 * The BinaryNode object contains an element and maybe have a neighbour( the next element in the list).
 * @param <E> The type of the element contained in the node.
 */
public class ListNode<E> {
	// data attributes
	private E element;
	private ListNode <E> next;

	/* constructors */
	
	/**
	 * Construct a node with specified element.
	 * @param item The specified element.
	 */
	public ListNode(E item) { 
		this(item, null); 
	}

	/**
	 * Construct a node with specified element and neighbour.
	 * @param item The specified element.
	 * @param n A node is as the neighbour.
	 */
	public ListNode(E item, ListNode <E> n) { 
		element = item; 
		next = n; 
	}

	/** 
	 * Get the next element in the list
	 * @return A node in the next position
	 */
	public ListNode <E> getNext() {
		return next;
	}

	/**
	 * Get the element contained in the node
	 * @return The element in the node
	 */
	public E getElement() {
		return element;
	}

	/**
	 * Set a node in the next position
	 * @param n A node to setted
	 */
	public void setNext(ListNode <E> n) {
		next = n;
	}
}
