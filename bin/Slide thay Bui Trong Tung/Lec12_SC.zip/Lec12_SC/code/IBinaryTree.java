package samsung.java.binary.tree;

/**
 * A tree whose every node has no more than two children.
 * @param <E> The type of the elements in the tree.
 */
public interface IBinaryTree<E> {

	/**
	 * Get the root of the tree.
	 * @return The BInaryNode roots the tree.
	 */
	public abstract BinaryNode<E> getRoot();


	
	/**
	 * Set the specified root for the tree.
	 * @param r The specified root.
	 */
	public void setRoot(BinaryNode<E> r);
	
	/** Check whether tree is empty. 
	 * @return true if the tree contains no element.
	 */
	public abstract boolean isEmpty();

	/**
	 * Removes all of the elements from the tree.
	 */
	public abstract void clear();
	
	/**
	 * Get the number of nodes in the tree.
	 * @return The 0 value if the tree is empty.
	 */
	public abstract int size();

	/**
	 * Get the height of the tree.
	 * @return The -1 valude if the tree is empty. The 0 value if the tree has only root.
	 */
	public abstract int height();

	/**
	 * Visit tree by using in-order traversal.
	 */
	public abstract void visitInOrder();

	/**
	 * Visit tree by using pre-order traversal.
	 */
	public abstract void visitPreOrder();

	/**
	 * Visit tree by using pos-order traversal.
	 */
	public abstract void visitPosOrder();

}