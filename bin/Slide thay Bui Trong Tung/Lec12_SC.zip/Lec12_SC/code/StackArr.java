package samsung.java.stack;

import java.util.EmptyStackException;

/**
 * An implementation of the IStack interface by using array.
 * @param <E> The type of the elements in this stack
 */
public class StackArr<E> implements IStack<E> {

	private E[] arr;
	private int top;
	private int maxSize;
	private final int INITSIZE = 1000;

	/**
	 * Create an empty stack
	 */
	public StackArr() {
		arr = (E[]) new Object[INITSIZE]; // creating array of type E
		top = -1;  // empty stack - thus, top is not on an valid array element
		maxSize = INITSIZE;
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#isEmpty()
	 */
	public boolean empty() { 
		return (top < 0); 
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#peek()
	 */
	public E peek() throws EmptyStackException {
		if (!empty()) return arr[top];
		else throw new EmptyStackException();
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#pop()
	 */
	public E pop() throws EmptyStackException {
		E obj = peek();
		top--;
		return obj;
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#push(java.lang.Object)
	 */
	public void push(E obj) {
		if (top >= maxSize - 1) enlargeArr();
		top++;
		arr[top] = obj;
	}

	/**
	 * Internal methods to double the number of entries in the array when there is not enough space
	 */
	private void enlargeArr() {
		int newSize = 2 * maxSize;
		E[] x = (E[]) new Object[newSize];

		for (int j=0; j < maxSize; j++) {
			x[j] = arr[j];
		}
		maxSize = newSize;
		arr = x;
	}

}
