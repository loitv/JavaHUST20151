package samsung.java.binary.tree;

/**
 * The implementation of the IBinaryTree interface.
 * @param <E> The type of elements in this tree.
 */
public class BinaryTree<E> implements IBinaryTree<E> {
	private BinaryNode<E> root;
	
	//Constructors
	/**
	 * Constructs an empty tree.
	 */
	public BinaryTree(){
		root = null;
	}
	
	/**
	 * Constructs a new tree contains the specified root.
	 * @param rootItem The specified root.
	 */
	public BinaryTree(E rootItem){
		root = new BinaryNode<E>(rootItem, null, null);
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#getRoot()
	 */
	@Override
	public BinaryNode<E> getRoot(){
		return root;
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#setRoot(samsung.java.binary.tree.BinaryNode)
	 */
	public void setRoot(BinaryNode<E> r){
		root = r;
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#size()
	 */
	@Override
	public int size(){
		return size(root);
	}
	
	/**
	 * Internal method to calculate the size of the subtree.
	 * @param n The node that roots the subtree.
	 * @return The height of the subtree rooted by n.
	 */
	private int size(BinaryNode<E> n){
		if (n == null)
			return 0;
		else return 1 + size(n.getLeft()) + size(n.getRight());
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#height()
	 */
	@Override
	public int height(){
		return height(root);
	}
	
	/**
	 * Internal method to calculate the height of the subtree.
	 * @param n The node that roots the subtree.
	 * @return The height of the subtree rooted by n.
	 */
	private int height(BinaryNode<E> n){
		if(n == null)
			return -1;
		else
			return 1 + Math.max(height(n.getLeft()), height(n.getRight()));
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#visitInOrder()
	 */
	@Override
	public void visitInOrder(){
		visitInOrder(root);
	}
	
	/**
	 * Internal method to visit the subtree by pre-order.
	 * @param n The node that roots the subtree.
	 */
	private void visitInOrder(BinaryNode<E> n){
		if(n.hasLeft())
			visitInOrder(n.getLeft());
		System.out.println(n.getElement());
		if(n.hasRight())
			visitInOrder(n.getRight());
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#visitPreOrder()
	 */
	@Override
	public void visitPreOrder(){
		visitPreOrder(root);
	}
	
	/**
	 * Internal method to visit the subtree by pre-order.
	 * @param n The node that roots the subtree.
	 */
	private void visitPreOrder(BinaryNode<E> n){
		
		System.out.println(n.getElement());
		
		if(n.hasLeft())
			visitPreOrder(n.getLeft());
		
		if(n.hasRight())
			visitPreOrder(n.getRight());
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#visitPosOrder()
	 */
	@Override
	public void visitPosOrder(){
		visitPosOrder(root);
	}
	
	/**
	 * Internal method to visit the subtree by pos-order.
	 * @param n The node that roots the subtree.
	 */
	private void visitPosOrder(BinaryNode<E> n){
		if(n.hasLeft())
			visitPosOrder(n.getLeft());
		
		if(n.hasRight())
			visitPosOrder(n.getRight());
		
		System.out.println(n.getElement());
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#isEmpty()
	 */
	@Override
	public boolean isEmpty(){
		return root == null;
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.tree.IBinaryTree#clear()
	 */
	@Override
	public void clear(){
		root = null;
	}

}
