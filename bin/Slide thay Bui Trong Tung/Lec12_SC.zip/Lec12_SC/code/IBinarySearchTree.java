package samsung.java.binary.search.tree;

import samsung.java.binary.tree.BinaryNode;

/**
 * A BinaryTree whose elements are ordered by a Comparator provided at tree creation time.
 * This tree provides guaranteed log(n) time cost for the basic operations (insert and find). 
 * @param <E> The type of elements in the tree.
 */
public interface IBinarySearchTree<E> {

	/**
	 * Inserts a new node into the tree.
	 * @param item Element to be inserted.  
	 * @throws DuplicateItemException If the element has already existed in tree.
	 */
	public void insert(E item) throws DuplicateItemException;
	
	/**
	 * Find a elements in the tree.
	 * @param item Element to be searched.
	 * @return The node contains found element. Return null if could not found the element.
	 */
	public BinaryNode<E> find(E item);
}
