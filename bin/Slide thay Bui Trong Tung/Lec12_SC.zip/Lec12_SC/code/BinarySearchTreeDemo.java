package samsung.java.data.structure.demo;

import java.util.Comparator;

import samsung.java.binary.search.tree.BinarySearchTree;
import samsung.java.binary.search.tree.DuplicateItemException;

public class BinarySearchTreeDemo {
	public static class IntComparator implements Comparator<Integer>{
		@Override
		public int compare(Integer o1, Integer o2) {
			return o1.compareTo(o2);
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Comparator<Integer> c = new IntComparator();
		BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>(c);
		
		try {
			tree.insert(6);
			tree.insert(3);
			tree.insert(7);
			tree.insert(1);
			tree.insert(5);
			tree.insert(4);
			tree.insert(9);
		} catch (DuplicateItemException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		System.out.println("Visit by in-order");
		tree.visitInOrder();
		System.out.println("Visit by pre-order");
		tree.visitPreOrder();
		System.out.println("Visit by pos-order");
		tree.visitPosOrder();
		
		if (tree.find(4) != null)
			System.out.println("Found item!");
		else 
			System.out.println("Could not found item!");
		
		if (tree.find(8) != null)
			System.out.println("Found item!");
		else 
			System.out.println("Could not found item!");
	}

}
