package samsung.java.stack;

import java.util.EmptyStackException;

/**
 * The stack is a collection of data that is accessed in a last-in-first-out (LIFO) manner.
 * @param <E> The type of the elements in stack.
 */
public interface IStack<E> {
	
	/**
	 * Check whether stack is empty.
	 * @return true if the stack contains no element.
	 */
	public boolean empty(); 
	
	/**
	 * Looks at the object at the top of this stack without removing it from the stack.
	 * @return The object at the top of this stack
	 * @throws EmptyStackException if this stack is empty.
	 */
	public E peek() throws EmptyStackException;
	
	/**
	 * Removes the object at the top of this stack and returns that object as the value of this function.
	 * @return The object at the top of this stack
	 * @throws EmptyStackException if this stack is empty.
	 */
	public E pop() throws EmptyStackException;

	/**
	 * Pushes an item onto the top of this stack.
	 * @param item The item to be pushed onto this stack.
	 */
	public void push(E item);
}
