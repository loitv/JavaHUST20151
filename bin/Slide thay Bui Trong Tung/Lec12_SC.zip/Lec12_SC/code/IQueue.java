package samsung.java.queue;

/**
 * The queue is a collection of data that is accessed in a first-in-first-out (FIFO) manner
 * @param <E> The types of the elements in the queue.
 */
public interface IQueue<E> {
	
	/**
	 * Check whether queue is empty.
	 * @return true if the queue contains no element.
	 */
	public boolean  isEmpty();

	/**
	 * Retrieves, but does not remove, the head of the queue (in other words, the first element of this queue),
	 * or returns null if this queue is empty.
	 * @return The head of the queue, or null if this queue is empty
	 */
	public E        peek();

	/**
	 * Retrieves and removes the head of the queue (in other words, the first element of this queue),
	 * or returns null if this queue is empty.
	 * @return The first element of the queue, or null if this queue is empty
	 */
	public E        poll(); // also commonly known as dequeue

	/**
	 * Inserts the specified element into the queue (in other words, the first element of this queue),
	 * if it is possible to do so immediately without violating capacity restrictions. 
	 * Returning true upon success and false if no space is currently available.
	 * @param item The element to add
	 * @return true if the element was added to this queue, else false
	 */
	public boolean offer(E item); // also commonly known as enqueue
}
