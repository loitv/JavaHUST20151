package samsung.java.data.structure.demo;

import samsung.java.binary.tree.BinaryNode;
import samsung.java.binary.tree.BinaryTree;
import samsung.java.binary.tree.IBinaryTree;

public class BinaryTreeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IBinaryTree<String> tree = new BinaryTree<String>("A");
		
		
		BinaryNode<String> left = new BinaryNode<String>("B");
		tree.getRoot().addLeft(left);
		left.addLeft(new BinaryNode<String>("D"));
		left.addRight(new BinaryNode<String>("E"));
		BinaryNode<String> right;
		right = left.getRight();
		right.addLeft(new BinaryNode<String>("G"));
		
		right = new BinaryNode<String>("C");
		tree.getRoot().addRight(right);
		right.addRight(new BinaryNode<String>("F"));
		
		System.out.println("Visit tree by in-order");
		tree.visitInOrder();
		
		System.out.println("Visit tree by pre-order");
		tree.visitPreOrder();
		
		System.out.println("Visit tree by pos-order");
		tree.visitPosOrder();
	}
}
