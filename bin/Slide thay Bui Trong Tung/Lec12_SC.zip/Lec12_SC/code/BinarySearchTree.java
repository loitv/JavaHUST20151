package samsung.java.binary.search.tree;

import java.util.Comparator;

import samsung.java.binary.tree.BinaryNode;
import samsung.java.binary.tree.BinaryTree;


/**
 * The implementation of the IBinarySerchTree interface. The BinarySearchTree also extends from the BinaryTree class.
 * @param <E> The type of elements in this tree
 */
public class BinarySearchTree<E> extends BinaryTree<E>
								 implements IBinarySearchTree<E> {
	private BinaryNode<E> root;
	private Comparator<E> comparator;
	
	/**
	 * Constructs a new, empty Binary Search Tree, sorted according to the specified comparator. 
	 * @param c The comparator that will be used to order this set.
	 */
	public BinarySearchTree(Comparator<E> c){
		root = null;
		comparator = c;
	}
	
	/**
	 * Constructs a new tree contains the specified root, sorted according to the comparator.
	 * @param r The specified root.
	 * @param c The comparator.
	 */
	public BinarySearchTree(BinaryNode<E> r, Comparator<E> c){
		root = r;
		comparator = c;
	}
	
	/* (non-Javadoc)
	 * @see samsung.java.binary.search.tree.IBinarySearchTree#insert(java.lang.Object)
	 */
	@Override
	public void insert(E item) throws DuplicateItemException {
		root = insert(item, root);
		super.setRoot(root);
	}

	/**
	 * Internal method to insert an item into a subtree.
	 * @param item The element to be inserted.
	 * @param t The node that roots the subtree.
	 * @return The root of the subtree containing new element.
	 * @throws DuplicateItemException If the element has already existed in tree.
	 */
	private BinaryNode<E> insert(E item, BinaryNode<E> t) throws DuplicateItemException {
		if(t == null)
			t = new BinaryNode<E>(item);
		else if(comparator.compare(item, t.getElement()) < 0)
			t.addLeft(insert(item, t.getLeft()));
		else if(comparator.compare(item, t.getElement()) > 0)
			t.addRight(insert(item, t.getRight()));
		else
			throw new DuplicateItemException(item.toString());
		return t;
	}

	/* (non-Javadoc)
	 * @see samsung.java.binary.search.tree.IBinarySearchTree#find(java.lang.Object)
	 */
	@Override
	public BinaryNode<E> find(E item) {
		return find(item, root);
	}

	/**
	 * Internal method to find an item in a subtree.
	 * @param item The element to be searched in subtree.
	 * @param t The node that roots the subtree.
	 * @return Node contains the matched item.
	 */
	private BinaryNode<E> find(E item, BinaryNode<E> t) {
		while(t != null){
			if(comparator.compare(item, t.getElement()) < 0)
				t = t.getLeft();
			else if (comparator.compare(item, t.getElement()) > 0)
				t = t.getRight();
			else return t;
		}
		return null;
	}
}
