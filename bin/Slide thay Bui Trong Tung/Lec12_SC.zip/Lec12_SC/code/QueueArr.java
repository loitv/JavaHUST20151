package samsung.java.queue;

/**
 * The implementation of the IQueue interface by using array.
 * @param <E> The type onf the elements in this queue.
 */
public class QueueArr<E> implements IQueue<E> {
	private E [] arr;
	private int front, back;
	private int maxSize;
	private final int INITSIZE = 1000;

	/**
	 * Create an empty queue
	 */
	public QueueArr() {
		arr = (E []) new Object[INITSIZE]; // create array of E objects
		front = 0; // the queue is empty
		back = 0;
		maxSize = INITSIZE;
	}

	/* (non-Javadoc)
	 * @see samsung.java.queue.IQueue#isEmpty()
	 */
	public boolean isEmpty() { 
		return (front == back); 
	}

	/* (non-Javadoc)
	 * @see samsung.java.queue.IQueue#peek()
	 */
	public E peek() {
		if (isEmpty()) return null;
		else return arr[front];
	}

	/* (non-Javadoc)
	 * @see samsung.java.queue.IQueue#poll()
	 */
	public E poll() {
		E obj = arr[front];
		arr[front] = null;
		front = (front + 1) % maxSize;
		return obj;
	}

	/* (non-Javadoc)
	 * @see samsung.java.queue.IQueue#offer(java.lang.Object)
	 */
	public boolean offer(E o) {
		if (((back+1)%maxSize) == front) // array is full
			return false;
		
		arr[back] = o;
		back = (back + 1) % maxSize;
		return true;
	}
}
