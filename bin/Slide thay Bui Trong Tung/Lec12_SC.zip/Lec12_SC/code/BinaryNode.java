package samsung.java.binary.tree;

/**
 * The BinaryNode class demonstrates a node in the binary tree.
 * The BinaryNode object contains an element and maybe have children.
 * @param <E> The type of element in the node.
 */
public class BinaryNode<E> {
	private E element;
	private BinaryNode<E> left;
	private BinaryNode <E> right;
	
	/**
	 * Constructs an empty node
	 */
	public BinaryNode(){
		this(null,null,null);
	}
	
	/**
	 * Constructs a node with a specified element
	 * @param item The specified element
	 */
	public BinaryNode(E item){
		this(item, null,null);
	}
	
	/**
	 * Constructs a node with a specified element and children
	 * @param item The element
	 * @param l The left child
	 * @param r The right child
	 */
	public BinaryNode(E item, BinaryNode<E> l, BinaryNode<E> r){
		this.element = item;
		this.left = l;
		this.right = r;
	}
	
	/**
	 * Return the element that is contained in node
	 * @return The element
	 */
	public E getElement(){
		return this.element;
	}
	
	/**
	 * Return the left child of the node
	 * @return The left child
	 */
	public BinaryNode<E> getLeft(){
		return this.left;
	}
	
	/**
	 * Return the right child of the node
	 * @return The right child
	 */
	public BinaryNode<E> getRight(){
		return this.right;
	}
	
	/**
	 * Set new element for the node
	 * @param item New element
	 */
	public void setElement(E item){
		this.element = item;
	}
	
	/**
	 * Add a specific node as left child
	 * @param l A BinaryNode
	 */
	public void addLeft(BinaryNode<E> l){
		this.left = l;
	}
	
	/**
	 * Add a specific node as right child
	 * @param r A BinaryNode
	 */
	public void addRight(BinaryNode<E> r){
		this.right = r;
	}
	
	/**
	 * Return the true value if the node has left child, otherwise return false
	 * @return true if the node has left child
	 */
	public boolean hasLeft(){
		return left != null;
	}
	
	/**
	 * Return the true value if the node has right child, otherwise return false
	 * @return true if the node has right child
	 */
	public boolean hasRight(){
		return right != null;
	}
	
}
