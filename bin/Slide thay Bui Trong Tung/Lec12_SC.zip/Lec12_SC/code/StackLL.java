package samsung.java.stack;

import java.util.EmptyStackException;
import java.util.NoSuchElementException;

import samsung.java.linked.list.BasicLinkedList;

/**
 * An implementation of the IStack interface by compositing BasicLinkedList object.
 * @param <E> The type of the elements in this stack.
 */
public class StackLL<E> implements IStack<E> {
	private BasicLinkedList <E> list;

	/**
	 * Create an empty stack
	 */
	public StackLL() {
		list = new BasicLinkedList <E> ();
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#empty()
	 */
	public boolean empty() {
		return list.isEmpty();
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#peek()
	 */
	public E peek() throws EmptyStackException {
		try {
			return list.getFirst();
		} catch (NoSuchElementException e) {
			throw new EmptyStackException();
		}
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#pop()
	 */
	public E pop() throws EmptyStackException {
		E obj = peek();
		list.removeFirst();
		return obj;
	}

	/* (non-Javadoc)
	 * @see samsung.java.stack.IStack#push(java.lang.Object)
	 */
	public void push(E o) {
		list.addFirst(o);
	}
}
