package samsung.java.binary.search.tree;

/**
 * Throw when a existing node is inserted into the tree.
 */
public class DuplicateItemException extends Exception {
	/**
	 * Constructs a DuplicateItemException with the specified detail message.
	 * @param msg The detail mesage.
	 */
	public DuplicateItemException(String msg){
		super(msg);
	}
}
