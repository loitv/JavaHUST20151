package samsung.java.linked.list;

import java.util.NoSuchElementException;

/**
 * A list of linked elements.
 * @param <E> The type of the elements in the list.
 */
public interface IList<E> {
	
	/**
	 * Check whether list is empty.
	 * @return true if the list contains no element.
	 */
	public boolean isEmpty();
	
	/**
	 * Return the number of the elements in the list.
	 * @return 0 if the list is empty.
	 */
	public int     size();
	
	/**
	 * Get the first element in the list.
	 * @return The first element in the list.
	 * @throws NoSuchElementException if the list is empty.
	 */
	public E       getFirst() throws NoSuchElementException; 
	
	/**
	 * Check whether the specified element exist in the list.
	 * @param item The element whose presence in this list is to be tested.
	 * @return true if this list contains the specified element.
	 */
	public boolean contains(E item);
	
	/**
	 * Inserts the specified element at the beginning of this list.
	 * @param item The element to add.
	 */
	public void    addFirst(E item);
	
	/**
	 * Removes and returns the first element from this list.
	 * @return The first element from this list.
	 * @throws NoSuchElementException if the list is empty.
	 */
	public E       removeFirst() throws NoSuchElementException;  
	
	/**
	 * Display the elements in this list.
	 * @throws NoSuchElementException if the list is empty.
	 */
	public void    print() throws NoSuchElementException;
}
